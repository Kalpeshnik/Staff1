package com.company.STAFF.MANAGEMENT.advanced;

public class A {

}
