package com.company.STAFF.MANAGEMENT.dao;

public class B {

}
