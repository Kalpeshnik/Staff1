package com.company.STAFF.MANAGEMENT.entity;

public class ObjectNotFoundException extends RuntimeException
{
	
	public ObjectNotFoundException(String message)
	{
		super(message);
	}

}
