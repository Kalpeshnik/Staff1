package com.company.STAFF.MANAGEMENT.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.STAFF.MANAGEMENT.dao.MobileDAO;
import com.company.STAFF.MANAGEMENT.entity.Mobile;

@Service
public class MobileService 
{
	
	@Autowired
	MobileDAO dao;
	
	public List<Mobile> getAllMobiles()
	{
			return dao.getAllMobiles();
	}
	
}
