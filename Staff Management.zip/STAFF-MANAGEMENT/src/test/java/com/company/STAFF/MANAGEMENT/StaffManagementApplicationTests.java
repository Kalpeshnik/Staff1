package com.company.STAFF.MANAGEMENT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StaffManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
